#include<stdio.h>
#include<conio.h>
static void main()
{
int num;
clrscr();
printf("Enter Number");
scanf("%d",num);
if(num%2==0)
{
printf("%d is even number");
}
else
prinf("%d is odd number");
}
getchar();
}