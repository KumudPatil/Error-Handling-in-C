#include<stdio.h>
#include<conio.h>
void main()
{
int num;
clrscr();
printf("Enter Number");
scanf("%d",&num);
square=(num*num);
printf("Square =%d",square);
getch();
}