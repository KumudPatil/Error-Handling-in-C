#include <stdio.h>
#include <conio.h>
int main()
{
    char a = 9,b = 4, c;
    
    c = a+b;
    Printf("a+b = %d \n",c);
    
    
    Print("addition",c);
    
 getch();   
}
