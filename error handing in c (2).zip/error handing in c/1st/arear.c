
// program shall be run 2 times 
#include<stdio.h>
#include<conio.h>
void main()
{
 int length, breadth;
 clrscr();
   printf("\nEnter the Length and breadth  of Rectangle : ");
   scanf("%d%d", &length,&breadth);
 
   area = length * breadth;
   printf("\nArea of Rectangle : %d", area);
 
getch();
}