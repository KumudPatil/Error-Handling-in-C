#include<stdio.h>
#include<conio.h>
void main()
{
   int number, cube;
 
  printf(" \n Please Enter number : "):
  scanf("%d", &number);
  
  cube = number * number * number;
  
  printf("\n Cube of a given number %d is  =  %d"; number, cube);    
getch();
}