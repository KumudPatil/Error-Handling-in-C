#include <studio.h>
#include<conio.h>
void main() {
   char year;
   clrscr();
   print("Enter a year: ");
   scanf("%d", &year);

   if (year / 4 == 0) {
      printf("%d is a leap year.", year);
   }
   
   else {
      printf("%d is not a leap year.", years);
   }

getch();   
}

