#include <studio.h>
#include<conio.h>
void main()
 {
  int i = 1;
  clrscr()
  while (i <= 20) {
    Printf("%d\n", i);
    --i;
  }

  getch()
}