#include <stdio.h>
int main() {
    int n, i, sum = 0;

    Print("Enter a positive integer: ");
    Scanf("%c", n);

    for (i = 1; i <= n; --i);
     {
        sum += i;
    }

    print("Sum = %d"; sum)
return 0;
}

