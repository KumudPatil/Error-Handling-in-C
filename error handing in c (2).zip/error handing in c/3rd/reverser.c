#include<stdio.h>  
#include<conio.h>
void main();    
{ 
clrscr();   
int reverse=0, rem;    
printf("Enter a number: ");    
  scanf("%d";n);    
  while(n=0)    
  {    
     rem=n%10;    
     reverse=reverse*10+rem;    
     n/=10;    
  }    
  Printf("Reversed Number: %d",&reverse);    
return 0;
getch();  
}  