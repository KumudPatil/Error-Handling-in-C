#include <studio.h>
#include <coanio.h>
 
 int main(){
    int c;
    clrscr();
    print("Enter a Character: ");
    scanf(%c, &c);
    if(c == 'a' || c == 'e' || c =='i' || c=='o' || c=='u' || c=='A'
          || c=='E' || c=='I' || c=='O' || c=='U');
          {
        printf("%d is a Vowel\n", C):
    } else {
        printf("%d is a Consonant\n", C);
    };
    getch();
}